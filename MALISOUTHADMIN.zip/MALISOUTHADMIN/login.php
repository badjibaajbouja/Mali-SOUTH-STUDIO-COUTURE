<?php
// login.php - administrator sign in (customers cannot sign in here)
require_once 'includes/config.php';
if (is_admin()) { header('Location: index.php'); exit; }

$error = '';
$email = '';
$locked = isset($_SESSION['locked_until']) && $_SESSION['locked_until'] > time();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($locked) {
        $error = 'Too many failed attempts. Please wait 5 minutes and try again.';
    } else {
        csrf_check();
        $email = trim($_POST['email']);
        $pass  = $_POST['password'];

        // only accounts with the admin role are looked up
        $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE email = ? AND role = 'admin'");
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if ($user && password_verify($pass, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']     = $user['id'];
            $_SESSION['full_name']   = $user['full_name'];
            $_SESSION['role']        = $user['role'];
            $_SESSION['last_active'] = time();
            unset($_SESSION['fails'], $_SESSION['locked_until']);
            header('Location: index.php');
            exit;
        }

        // wrong details: after 5 tries in a row the login is paused for 5 minutes
        $_SESSION['fails'] = (isset($_SESSION['fails']) ? $_SESSION['fails'] : 0) + 1;
        if ($_SESSION['fails'] >= 5) {
            $_SESSION['locked_until'] = time() + 300;
            $_SESSION['fails'] = 0;
        }
        $error = 'Incorrect email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Admin Login | Mali South Studio Couture</title>
    <link rel="stylesheet" href="<?php echo ADMIN_URL; ?>css/admin.css">
</head>
<body class="login-page">
    <div class="login-card">
        <div class="login-brand">MALI SOUTH<small>ADMIN PORTAL</small></div>
        <?php show_flash(); ?>
        <?php if ($error != ''): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
        <form method="post">
            <?php echo csrf_field(); ?>
            <label>Email</label>
            <input type="email" name="email" value="<?php echo e($email); ?>" required autofocus>
            <label>Password</label>
            <input type="password" name="password" required>
            <button type="submit" class="btn btn-burgundy btn-block">Log in</button>
        </form>
        <p class="login-note">Staff only. Customers can shop on the <a href="<?php echo CUSTOMER_URL; ?>index.php">customer website</a>.</p>
    </div>
</body>
</html>
