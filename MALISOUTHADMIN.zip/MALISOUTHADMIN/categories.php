<?php
// admin/categories.php - add, edit and delete categories
require_once 'includes/header.php';

$edit = null;
$errors = [];
$images = list_asset_images();

// ---- DELETE ----
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_id'])) {
    csrf_check();
    $id = (int)$_POST['delete_id'];
    $used = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM products WHERE category_id = $id"));
    if ($used[0] > 0) {
        set_flash('error', 'This category still has products. Move or delete those products first.');
    } else {
        mysqli_query($conn, "DELETE FROM categories WHERE id = $id");
        set_flash('success', 'Category deleted.');
    }
    header('Location: categories.php');
    exit;
}

// ---- SAVE ----
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save'])) {
    csrf_check();
    $id = (int)$_POST['id'];
    $name = trim($_POST['name']);
    $chosen = $_POST['image'];

    if ($name == '') { $errors[] = 'The category name is required.'; }

    // slug = the name written in lower case with dashes, e.g. "Traditional Outfits" -> traditional-outfits
    $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($name)), '-');
    if ($slug == '' && $name != '') { $errors[] = 'The name must contain letters or numbers.'; }
    $se = mysqli_real_escape_string($conn, $slug);
    $dup = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM categories WHERE slug = '$se' AND id != $id"));
    if ($dup[0] > 0) { $errors[] = 'A category with that name already exists.'; }

    $upload_error = '';
    $uploaded = upload_image('image_file', $upload_error);
    if ($uploaded === false) { $errors[] = $upload_error; }
    $image = in_array($chosen, $images) ? $chosen : '';
    if ($uploaded) { $image = $uploaded; }

    if (count($errors) == 0) {
        $n = mysqli_real_escape_string($conn, $name);
        $i = mysqli_real_escape_string($conn, $image);
        if ($id > 0) {
            mysqli_query($conn, "UPDATE categories SET name='$n', slug='$se', image='$i' WHERE id=$id");
            set_flash('success', 'Category updated.');
        } else {
            mysqli_query($conn, "INSERT INTO categories (name, slug, image) VALUES ('$n', '$se', '$i')");
            set_flash('success', 'Category added.');
        }
        header('Location: categories.php');
        exit;
    }
    $edit = ['id' => $id, 'name' => $name, 'image' => $image];
}

if ($edit === null && isset($_GET['edit'])) {
    $eid = (int)$_GET['edit'];
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM categories WHERE id = $eid"));
}

$list = mysqli_query($conn, "SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count FROM categories c ORDER BY c.name");
?>
<h1>Categories</h1>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?php echo e($err); ?></div><?php endforeach; ?>

<form method="post" enctype="multipart/form-data" class="form-card wide">
    <h3><?php echo ($edit && $edit['id'] > 0) ? 'Edit Category' : 'Add Category'; ?></h3>
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo $edit ? (int)$edit['id'] : 0; ?>">
    <label>Name</label>
    <input type="text" name="name" value="<?php echo $edit ? e($edit['name']) : ''; ?>" required>
    <label>Picture - choose one that is already on the site</label>
    <select name="image">
        <option value="">(no picture)</option>
        <?php foreach ($images as $f): ?>
            <option value="<?php echo e($f); ?>" <?php echo ($edit && $edit['image'] == $f) ? 'selected' : ''; ?>><?php echo e($f); ?></option>
        <?php endforeach; ?>
    </select>
    <label>...or upload a new picture (JPG, PNG or WEBP, max 3 MB)</label>
    <input type="file" name="image_file" accept=".jpg,.jpeg,.png,.webp">
    <button type="submit" name="save" value="1" class="btn btn-burgundy"><?php echo ($edit && $edit['id'] > 0) ? 'Update' : 'Add'; ?> Category</button>
    <?php if ($edit): ?><a href="categories.php" class="btn btn-outline">Cancel</a><?php endif; ?>
</form>

<table class="table">
    <tr><th>ID</th><th>Image</th><th>Name</th><th>Slug</th><th>Products</th><th>Actions</th></tr>
    <?php while ($c = mysqli_fetch_assoc($list)): ?>
    <tr>
        <td><?php echo $c['id']; ?></td>
        <td><?php if ($c['image'] != ''): ?><img src="<?php echo img($c['image']); ?>" class="thumb" alt=""><?php endif; ?></td>
        <td><?php echo e($c['name']); ?></td>
        <td><?php echo e($c['slug']); ?></td>
        <td><?php echo $c['product_count']; ?></td>
        <td>
            <div class="row-actions">
                <a href="categories.php?edit=<?php echo $c['id']; ?>">Edit</a>
                <form method="post" onsubmit="return confirm('Delete this category?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="delete_id" value="<?php echo $c['id']; ?>">
                    <button type="submit" class="link-btn">Delete</button>
                </form>
            </div>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php require_once 'includes/footer.php'; ?>
