<?php
// setup.php - run once to create the first administrator, then DELETE this file.
// It refuses to do anything if an admin account already exists.
require_once 'includes/config.php';

$has_admin = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM users WHERE role = 'admin'"))[0] > 0;
$errors = [];
$done = false;
$name = '';
$email = '';

if (!$has_admin && $_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_check();
    $name    = trim($_POST['full_name']);
    $email   = trim($_POST['email']);
    $pass    = $_POST['password'];
    $confirm = $_POST['confirm'];

    if ($name == '') { $errors[] = 'Please enter your name.'; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = 'Please enter a valid email address.'; }
    if (strlen($pass) < 8) { $errors[] = 'The password must be at least 8 characters.'; }
    if ($pass !== $confirm) { $errors[] = 'The passwords do not match.'; }

    if (count($errors) == 0) {
        $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        if (mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0) {
            $errors[] = 'That email is already used by another account. Use a different email.';
        }
    }

    if (count($errors) == 0) {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, 'admin')");
        mysqli_stmt_bind_param($stmt, 'sss', $name, $email, $hash);
        mysqli_stmt_execute($stmt);
        $done = true;
        $has_admin = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Admin Setup | Mali South Studio Couture</title>
    <link rel="stylesheet" href="<?php echo ADMIN_URL; ?>css/admin.css">
</head>
<body class="login-page">
    <div class="login-card">
        <div class="login-brand">MALI SOUTH<small>ADMIN SETUP</small></div>
        <?php if ($done): ?>
            <div class="alert alert-success">Your admin account has been created.</div>
            <p>Now <strong>delete the file setup.php</strong> from the MALISOUTHADMIN folder, then <a href="login.php">log in</a>.</p>
        <?php elseif ($has_admin): ?>
            <div class="alert alert-error">An admin account already exists, so setup is switched off.</div>
            <p>Delete the file <strong>setup.php</strong> and <a href="login.php">log in</a>.</p>
        <?php else: ?>
            <?php foreach ($errors as $err): ?><div class="alert alert-error"><?php echo e($err); ?></div><?php endforeach; ?>
            <form method="post">
                <?php echo csrf_field(); ?>
                <label>Full name</label>
                <input type="text" name="full_name" value="<?php echo e($name); ?>" required>
                <label>Email</label>
                <input type="email" name="email" value="<?php echo e($email); ?>" required>
                <label>Password (at least 8 characters)</label>
                <input type="password" name="password" required>
                <label>Confirm password</label>
                <input type="password" name="confirm" required>
                <button type="submit" class="btn btn-burgundy btn-block">Create admin account</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
