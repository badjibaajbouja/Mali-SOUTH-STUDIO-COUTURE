<?php
// admin/products.php - search, add, edit (with picture upload) and delete products
require_once 'includes/header.php';

$edit = null;
$errors = [];
$images = list_asset_images();

// ---- DELETE ----
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_id'])) {
    csrf_check();
    $id = (int)$_POST['delete_id'];
    // a product that is already in an order cannot be deleted (foreign key)
    $used = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM order_items WHERE product_id = $id"));
    if ($used[0] > 0) {
        set_flash('error', 'This product is part of an order, so it cannot be deleted. Set its stock to 0 instead.');
    } else {
        mysqli_query($conn, "DELETE FROM products WHERE id = $id");
        set_flash('success', 'Product deleted.');
    }
    header('Location: products.php');
    exit;
}

// ---- SAVE (add or update) ----
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save'])) {
    csrf_check();
    $id    = (int)$_POST['id'];
    $cat   = (int)$_POST['category_id'];
    $name  = trim($_POST['name']);
    $desc  = trim($_POST['description']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    $chosen = $_POST['image'];

    if ($name == '') { $errors[] = 'The product name is required.'; }
    if ($price <= 0) { $errors[] = 'The price must be more than 0.'; }
    if ($stock < 0)  { $errors[] = 'Stock cannot be negative.'; }
    $cat_ok = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM categories WHERE id = $cat"));
    if ($cat_ok[0] == 0) { $errors[] = 'Please choose a category.'; }

    // picture: a new upload wins, otherwise the one picked from the list
    $upload_error = '';
    $uploaded = upload_image('image_file', $upload_error);
    if ($uploaded === false) { $errors[] = $upload_error; }
    $image = in_array($chosen, $images) ? $chosen : '';
    if ($uploaded) { $image = $uploaded; }

    if (count($errors) == 0) {
        $n = mysqli_real_escape_string($conn, $name);
        $d = mysqli_real_escape_string($conn, $desc);
        $i = mysqli_real_escape_string($conn, $image);
        if ($id > 0) {
            mysqli_query($conn, "UPDATE products SET category_id=$cat, name='$n', description='$d', price=$price, image='$i', stock=$stock WHERE id=$id");
            set_flash('success', 'Product updated.');
        } else {
            mysqli_query($conn, "INSERT INTO products (category_id, name, description, price, image, stock) VALUES ($cat, '$n', '$d', $price, '$i', $stock)");
            set_flash('success', 'Product added.');
        }
        header('Location: products.php');
        exit;
    }
    // validation failed: show the form again with what was typed
    $edit = ['id' => $id, 'category_id' => $cat, 'name' => $name, 'description' => $desc, 'price' => $price, 'stock' => $stock, 'image' => $image];
}

// ---- LOAD for the edit form ----
if ($edit === null && isset($_GET['edit'])) {
    $eid = (int)$_GET['edit'];
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM products WHERE id = $eid"));
}

// ---- search / filter ----
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$fcat = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$where = '1=1';
if ($q != '') {
    $qe = mysqli_real_escape_string($conn, $q);
    $where .= " AND p.name LIKE '%$qe%'";
}
if ($fcat > 0) { $where .= " AND p.category_id = $fcat"; }

$cats = mysqli_fetch_all(mysqli_query($conn, "SELECT * FROM categories ORDER BY name"), MYSQLI_ASSOC);
$list = mysqli_query($conn, "SELECT p.*, c.name AS cat FROM products p JOIN categories c ON p.category_id = c.id WHERE $where ORDER BY p.id DESC");
?>
<h1>Products</h1>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?php echo e($err); ?></div><?php endforeach; ?>

<form method="post" enctype="multipart/form-data" class="form-card wide">
    <h3><?php echo ($edit && $edit['id'] > 0) ? 'Edit Product' : 'Add Product'; ?></h3>
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo $edit ? (int)$edit['id'] : 0; ?>">
    <label>Category</label>
    <select name="category_id">
        <?php foreach ($cats as $c): ?>
            <option value="<?php echo $c['id']; ?>" <?php echo ($edit && $edit['category_id'] == $c['id']) ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option>
        <?php endforeach; ?>
    </select>
    <label>Name</label>
    <input type="text" name="name" value="<?php echo $edit ? e($edit['name']) : ''; ?>" required>
    <label>Description</label>
    <textarea name="description" rows="3"><?php echo $edit ? e($edit['description']) : ''; ?></textarea>
    <label>Price (R)</label>
    <input type="number" step="0.01" min="0" name="price" value="<?php echo $edit ? e($edit['price']) : ''; ?>" required>
    <label>Stock</label>
    <input type="number" min="0" name="stock" value="<?php echo $edit ? (int)$edit['stock'] : 0; ?>" required>
    <label>Picture - choose one that is already on the site</label>
    <select name="image">
        <option value="">(no picture)</option>
        <?php foreach ($images as $f): ?>
            <option value="<?php echo e($f); ?>" <?php echo ($edit && $edit['image'] == $f) ? 'selected' : ''; ?>><?php echo e($f); ?></option>
        <?php endforeach; ?>
    </select>
    <label>...or upload a new picture (JPG, PNG or WEBP, max 3 MB)</label>
    <input type="file" name="image_file" accept=".jpg,.jpeg,.png,.webp">
    <button type="submit" name="save" value="1" class="btn btn-burgundy"><?php echo ($edit && $edit['id'] > 0) ? 'Update' : 'Add'; ?> Product</button>
    <?php if ($edit): ?><a href="products.php" class="btn btn-outline">Cancel</a><?php endif; ?>
</form>

<form method="get" class="toolbar">
    <input type="text" name="q" placeholder="Search products by name" value="<?php echo e($q); ?>">
    <select name="cat">
        <option value="0">All categories</option>
        <?php foreach ($cats as $c): ?>
            <option value="<?php echo $c['id']; ?>" <?php echo $fcat == $c['id'] ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-burgundy btn-small">Filter</button>
    <a href="products.php" class="btn btn-outline btn-small">Reset</a>
</form>

<table class="table">
    <tr><th>ID</th><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Actions</th></tr>
    <?php if (mysqli_num_rows($list) == 0): ?>
        <tr><td colspan="7" class="empty-row">No products found.</td></tr>
    <?php endif; ?>
    <?php while ($p = mysqli_fetch_assoc($list)): ?>
    <tr class="<?php echo $p['stock'] <= 5 ? 'low-stock' : ''; ?>">
        <td><?php echo $p['id']; ?></td>
        <td><?php if ($p['image'] != ''): ?><img src="<?php echo img($p['image']); ?>" class="thumb" alt=""><?php endif; ?></td>
        <td><?php echo e($p['name']); ?></td>
        <td><?php echo e($p['cat']); ?></td>
        <td><?php echo money($p['price']); ?></td>
        <td><?php echo $p['stock']; ?></td>
        <td>
            <div class="row-actions">
                <a href="products.php?edit=<?php echo $p['id']; ?>">Edit</a>
                <form method="post" onsubmit="return confirm('Delete this product?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="delete_id" value="<?php echo $p['id']; ?>">
                    <button type="submit" class="link-btn">Delete</button>
                </form>
            </div>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php require_once 'includes/footer.php'; ?>
