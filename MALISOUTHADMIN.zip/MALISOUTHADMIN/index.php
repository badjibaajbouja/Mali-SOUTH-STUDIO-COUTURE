<?php
// admin/index.php - dashboard with totals, low stock and recent activity
require_once 'includes/header.php';

function count_rows($conn, $sql) {
    $r = mysqli_fetch_row(mysqli_query($conn, $sql));
    return $r[0];
}
$products   = count_rows($conn, "SELECT COUNT(*) FROM products");
$customers  = count_rows($conn, "SELECT COUNT(*) FROM users WHERE role='customer'");
$revenue    = count_rows($conn, "SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'Cancelled'");
$month_rev  = count_rows($conn, "SELECT COALESCE(SUM(total),0) FROM orders WHERE status != 'Cancelled' AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())");

$status_rows = mysqli_query($conn, "SELECT status, COUNT(*) AS n FROM orders GROUP BY status");
$low_stock   = mysqli_query($conn, "SELECT id, name, stock FROM products WHERE stock <= 5 ORDER BY stock ASC LIMIT 8");
$recent      = mysqli_query($conn, "SELECT o.*, u.full_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5");
$requests    = mysqli_query($conn, "SELECT * FROM custom_orders WHERE status = 'New' ORDER BY created_at DESC LIMIT 5");
?>
<h1>Dashboard</h1>
<div class="stat-grid">
    <div class="stat"><span><?php echo $products; ?></span>Products</div>
    <div class="stat"><span><?php echo $customers; ?></span>Customers</div>
    <div class="stat"><span><?php echo $pending_orders; ?></span>Pending orders</div>
    <div class="stat"><span><?php echo money($revenue); ?></span>Total revenue</div>
    <div class="stat"><span><?php echo money($month_rev); ?></span>Revenue this month</div>
    <div class="stat"><span><?php echo $new_requests; ?></span>New custom requests</div>
</div>

<div class="grid-2">
    <div>
        <h2>Orders by Status</h2>
        <table class="table">
            <tr><th>Status</th><th>Orders</th></tr>
            <?php if (mysqli_num_rows($status_rows) == 0): ?>
                <tr><td colspan="2" class="empty-row">No orders yet.</td></tr>
            <?php endif; ?>
            <?php while ($s = mysqli_fetch_assoc($status_rows)): ?>
                <tr><td><span class="status <?php echo status_class($s['status']); ?>"><?php echo e($s['status']); ?></span></td><td><?php echo $s['n']; ?></td></tr>
            <?php endwhile; ?>
        </table>
    </div>
    <div>
        <h2>Low Stock (5 or fewer)</h2>
        <table class="table">
            <tr><th>Product</th><th>Stock</th><th></th></tr>
            <?php if (mysqli_num_rows($low_stock) == 0): ?>
                <tr><td colspan="3" class="empty-row">All products are well stocked.</td></tr>
            <?php endif; ?>
            <?php while ($p = mysqli_fetch_assoc($low_stock)): ?>
                <tr><td><?php echo e($p['name']); ?></td><td><?php echo $p['stock']; ?></td><td><a href="products.php?edit=<?php echo $p['id']; ?>">Restock</a></td></tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

<h2>Recent Orders</h2>
<table class="table">
    <tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr>
    <?php if (mysqli_num_rows($recent) == 0): ?>
        <tr><td colspan="5" class="empty-row">No orders yet.</td></tr>
    <?php endif; ?>
    <?php while ($o = mysqli_fetch_assoc($recent)): ?>
    <tr>
        <td><a href="orders.php?q=<?php echo $o['id']; ?>">#<?php echo $o['id']; ?></a></td>
        <td><?php echo e($o['full_name']); ?></td>
        <td><?php echo money($o['total']); ?></td>
        <td><span class="status <?php echo status_class($o['status']); ?>"><?php echo e($o['status']); ?></span></td>
        <td><?php echo date('d M Y', strtotime($o['created_at'])); ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<h2>New Custom Order Requests</h2>
<table class="table">
    <tr><th>Date</th><th>Customer</th><th>Request</th><th></th></tr>
    <?php if (mysqli_num_rows($requests) == 0): ?>
        <tr><td colspan="4" class="empty-row">No new requests.</td></tr>
    <?php endif; ?>
    <?php while ($c = mysqli_fetch_assoc($requests)): ?>
    <tr>
        <td><?php echo date('d M Y', strtotime($c['created_at'])); ?></td>
        <td><?php echo e($c['full_name']); ?></td>
        <td><?php echo e($c['request_type']); ?></td>
        <td><a href="custom_orders.php?status=New">View</a></td>
    </tr>
    <?php endwhile; ?>
</table>
<?php require_once 'includes/footer.php'; ?>
