<?php
// includes/header.php - shared top of every admin page (sidebar + top bar)
require_once __DIR__ . '/config.php';
require_admin();
$current = basename($_SERVER['PHP_SELF']);

// small numbers shown next to some menu links
$pending_orders = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM orders WHERE status = 'Pending'"))[0];
$new_requests   = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM custom_orders WHERE status = 'New'"))[0];

$menu = [
    'index.php'         => 'Dashboard',
    'products.php'      => 'Products',
    'categories.php'    => 'Categories',
    'orders.php'        => 'Orders',
    'custom_orders.php' => 'Custom Orders',
    'customers.php'     => 'Customers',
    'messages.php'      => 'Messages',
    'settings.php'      => 'Settings',
];
$counts = ['orders.php' => $pending_orders, 'custom_orders.php' => $new_requests];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Admin Portal | Mali South Studio Couture</title>
    <link rel="stylesheet" href="<?php echo ADMIN_URL; ?>css/admin.css">
</head>
<body>
<div class="portal">
    <aside class="sidebar">
        <div class="brand">MALI SOUTH<small>ADMIN PORTAL</small></div>
        <nav>
            <?php foreach ($menu as $file => $label): ?>
                <a href="<?php echo $file; ?>" class="<?php echo $current == $file ? 'active' : ''; ?>"><?php echo $label; ?><?php if (!empty($counts[$file])): ?><span class="count"><?php echo $counts[$file]; ?></span><?php endif; ?></a>
            <?php endforeach; ?>
        </nav>
        <div class="side-bottom">
            <a href="<?php echo CUSTOMER_URL; ?>index.php" target="_blank" rel="noopener">View customer website</a>
            <a href="logout.php">Log out</a>
        </div>
    </aside>
    <div class="main">
        <header class="topbar">
            <span>Signed in as <strong><?php echo e($_SESSION['full_name']); ?></strong></span>
            <span><?php echo date('l, d F Y'); ?></span>
        </header>
        <main class="content">
<?php show_flash(); ?>
