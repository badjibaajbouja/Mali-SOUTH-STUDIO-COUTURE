<?php
// ------------------------------------------------------------
// functions.php - helper functions for the admin portal
// ------------------------------------------------------------

// Safely print text on a page (stops HTML/script injection)
function e($text) {
    return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
}

// Format a number as South African Rand
function money($amount) {
    return 'R' . number_format((float)$amount, 2);
}

// URL of a product picture (the pictures belong to the customer website)
function img($file) {
    return CUSTOMER_URL . 'assets/' . rawurlencode($file);
}

// Is an administrator logged in?
function is_admin() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Every admin page calls this first. Not logged in = back to the login page.
function require_admin() {
    if (!is_admin()) {
        header('Location: ' . ADMIN_URL . 'login.php');
        exit;
    }
    // sign out after 30 minutes without any activity
    if (isset($_SESSION['last_active']) && time() - $_SESSION['last_active'] > 1800) {
        $_SESSION = [];
        session_destroy();
        session_start();
        set_flash('error', 'You were signed out because you were inactive for 30 minutes.');
        header('Location: ' . ADMIN_URL . 'login.php');
        exit;
    }
    $_SESSION['last_active'] = time();
}

// Flash messages: shown once, then removed
function set_flash($type, $message) {
    $_SESSION['flash_' . $type] = $message;
}

function show_flash() {
    foreach (['success', 'error'] as $type) {
        if (isset($_SESSION['flash_' . $type])) {
            echo '<div class="alert alert-' . $type . '">' . e($_SESSION['flash_' . $type]) . '</div>';
            unset($_SESSION['flash_' . $type]);
        }
    }
}

// CSRF token: stops other websites from submitting admin forms for you
function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function csrf_check() {
    $sent = isset($_POST['csrf']) ? $_POST['csrf'] : '';
    if (!hash_equals(csrf_token(), $sent)) {
        die('Security check failed. Go back, refresh the page and try again.');
    }
}

// CSS class for a status badge, e.g. "In Progress" becomes "st-in-progress"
function status_class($status) {
    return 'st-' . strtolower(str_replace(' ', '-', $status));
}

// All picture files that are already inside the customer website's assets folder
function list_asset_images() {
    $names = [];
    foreach (glob(CUSTOMER_ASSETS . '/*.*') as $path) {
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            $names[] = basename($path);
        }
    }
    sort($names);
    return $names;
}

// Save an uploaded picture into the customer website's assets folder.
// Returns the new file name, '' if no file was chosen, or false if something is wrong.
function upload_image($field, &$error) {
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] == UPLOAD_ERR_NO_FILE) {
        return '';
    }
    $f = $_FILES[$field];
    if ($f['error'] != UPLOAD_ERR_OK) {
        $error = 'The image could not be uploaded.';
        return false;
    }
    if ($f['size'] > 3 * 1024 * 1024) {
        $error = 'The image must be smaller than 3 MB.';
        return false;
    }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp']) || @getimagesize($f['tmp_name']) === false) {
        $error = 'Only JPG, PNG or WEBP pictures are allowed.';
        return false;
    }
    $name = 'upload_' . time() . '_' . mt_rand(100, 999) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], CUSTOMER_ASSETS . '/' . $name)) {
        $error = 'The image could not be saved. Check that the customer website assets folder exists and is writable.';
        return false;
    }
    return $name;
}
?>
