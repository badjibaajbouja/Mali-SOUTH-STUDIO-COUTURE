<?php
// ------------------------------------------------------------
// config.php - ADMIN PORTAL: session, database connection, paths
// Included at the top of every admin page.
// ------------------------------------------------------------

// A different session name keeps the admin login completely separate
// from the customer website, even though both run on localhost.
session_name('MALISOUTH_ADMIN');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict']);
session_start();

// Folder names inside C:\xampp\htdocs - change them if you rename a folder
define('ADMIN_URL', '/MALISOUTHADMIN/');
define('CUSTOMER_URL', '/MALISOUTHSTUDIOCOUTURE/');

// Product pictures live in the customer website's assets folder
define('CUSTOMER_ASSETS', __DIR__ . '/../../MALISOUTHSTUDIOCOUTURE/assets');

// Same database as the customer website (XAMPP defaults)
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'mali_south_db';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error() .
        '. Did you start MySQL in XAMPP and import database.sql?');
}
mysqli_set_charset($conn, 'utf8mb4');

require_once __DIR__ . '/functions.php';
?>
