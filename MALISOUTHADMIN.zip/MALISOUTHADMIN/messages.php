<?php
// admin/messages.php - contact form messages
require_once 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_id'])) {
    csrf_check();
    $id = (int)$_POST['delete_id'];
    mysqli_query($conn, "DELETE FROM messages WHERE id = $id");
    set_flash('success', 'Message deleted.');
    header('Location: messages.php');
    exit;
}

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$where = '';
if ($q != '') {
    $qe = mysqli_real_escape_string($conn, $q);
    $where = "WHERE name LIKE '%$qe%' OR email LIKE '%$qe%' OR subject LIKE '%$qe%' OR message LIKE '%$qe%'";
}
$list = mysqli_query($conn, "SELECT * FROM messages $where ORDER BY created_at DESC");
?>
<h1>Messages</h1>
<form method="get" class="toolbar">
    <input type="text" name="q" placeholder="Search messages" value="<?php echo e($q); ?>">
    <button type="submit" class="btn btn-burgundy btn-small">Search</button>
    <a href="messages.php" class="btn btn-outline btn-small">Reset</a>
</form>

<table class="table">
    <tr><th>Date</th><th>From</th><th>Subject</th><th>Message</th><th></th></tr>
    <?php if (mysqli_num_rows($list) == 0): ?>
        <tr><td colspan="5" class="empty-row">No messages found.</td></tr>
    <?php endif; ?>
    <?php while ($m = mysqli_fetch_assoc($list)): ?>
    <tr>
        <td><?php echo date('d M Y', strtotime($m['created_at'])); ?></td>
        <td><?php echo e($m['name']); ?><br><small><a href="mailto:<?php echo e($m['email']); ?>"><?php echo e($m['email']); ?></a></small></td>
        <td><?php echo e($m['subject']); ?></td>
        <td><?php echo nl2br(e($m['message'])); ?></td>
        <td>
            <div class="row-actions">
                <a href="mailto:<?php echo e($m['email']); ?>?subject=<?php echo rawurlencode('Re: ' . $m['subject']); ?>">Reply</a>
                <form method="post" onsubmit="return confirm('Delete this message?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="delete_id" value="<?php echo $m['id']; ?>">
                    <button type="submit" class="link-btn">Delete</button>
                </form>
            </div>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php require_once 'includes/footer.php'; ?>
