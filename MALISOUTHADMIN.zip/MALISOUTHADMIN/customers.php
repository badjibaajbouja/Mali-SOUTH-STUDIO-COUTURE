<?php
// admin/customers.php - see all accounts, change roles, delete accounts without orders
require_once 'includes/header.php';

$me = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_check();
    $id = (int)$_POST['user_id'];

    if ($id == $me) {
        set_flash('error', 'You cannot change or delete your own account here.');
    } elseif (isset($_POST['make_role']) && in_array($_POST['make_role'], ['admin', 'customer'])) {
        $role = $_POST['make_role'];
        mysqli_query($conn, "UPDATE users SET role = '$role' WHERE id = $id");
        set_flash('success', 'Account role changed to ' . $role . '.');
    } elseif (isset($_POST['delete'])) {
        $used = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM orders WHERE user_id = $id"));
        if ($used[0] > 0) {
            set_flash('error', 'This customer has orders, so the account cannot be deleted.');
        } else {
            mysqli_query($conn, "DELETE FROM users WHERE id = $id");
            set_flash('success', 'Account deleted.');
        }
    }
    header('Location: customers.php');
    exit;
}

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$where = '';
if ($q != '') {
    $qe = mysqli_real_escape_string($conn, $q);
    $where = "WHERE u.full_name LIKE '%$qe%' OR u.email LIKE '%$qe%' OR u.phone LIKE '%$qe%'";
}
$list = mysqli_query($conn, "SELECT u.*,
        (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) AS order_count,
        (SELECT COALESCE(SUM(o.total), 0) FROM orders o WHERE o.user_id = u.id AND o.status != 'Cancelled') AS spent
        FROM users u $where ORDER BY u.id DESC");
?>
<h1>Customers</h1>
<form method="get" class="toolbar">
    <input type="text" name="q" placeholder="Search by name, email or phone" value="<?php echo e($q); ?>">
    <button type="submit" class="btn btn-burgundy btn-small">Search</button>
    <a href="customers.php" class="btn btn-outline btn-small">Reset</a>
</form>

<table class="table">
    <tr><th>ID</th><th>Name</th><th>Contact</th><th>Role</th><th>Orders</th><th>Spent</th><th>Joined</th><th>Actions</th></tr>
    <?php if (mysqli_num_rows($list) == 0): ?>
        <tr><td colspan="8" class="empty-row">No accounts found.</td></tr>
    <?php endif; ?>
    <?php while ($u = mysqli_fetch_assoc($list)): ?>
    <tr>
        <td><?php echo $u['id']; ?></td>
        <td><?php echo e($u['full_name']); ?></td>
        <td><small><a href="mailto:<?php echo e($u['email']); ?>"><?php echo e($u['email']); ?></a><br><?php echo e($u['phone']); ?></small></td>
        <td><?php echo e(ucfirst($u['role'])); ?></td>
        <td><?php echo $u['order_count']; ?></td>
        <td><?php echo money($u['spent']); ?></td>
        <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
        <td>
            <?php if ($u['id'] == $me): ?>
                <small>(you)</small>
            <?php else: ?>
            <div class="row-actions">
                <form method="post" onsubmit="return confirm('Change this account\'s role?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                    <button type="submit" name="make_role" value="<?php echo $u['role'] == 'admin' ? 'customer' : 'admin'; ?>" class="link-btn" style="color: var(--burgundy);"><?php echo $u['role'] == 'admin' ? 'Make customer' : 'Make admin'; ?></button>
                </form>
                <form method="post" onsubmit="return confirm('Delete this account?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                    <button type="submit" name="delete" value="1" class="link-btn">Delete</button>
                </form>
            </div>
            <?php endif; ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php require_once 'includes/footer.php'; ?>
