<?php
// admin/settings.php - change the admin password
require_once 'includes/header.php';

$errors = [];
$uid = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_check();
    $current = $_POST['current'];
    $new     = $_POST['new'];
    $confirm = $_POST['confirm'];

    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT password FROM users WHERE id = $uid"));
    if (!$row || !password_verify($current, $row['password'])) { $errors[] = 'Your current password is not correct.'; }
    if (strlen($new) < 8) { $errors[] = 'The new password must be at least 8 characters.'; }
    if ($new !== $confirm) { $errors[] = 'The new passwords do not match.'; }

    if (count($errors) == 0) {
        $hash = mysqli_real_escape_string($conn, password_hash($new, PASSWORD_DEFAULT));
        mysqli_query($conn, "UPDATE users SET password = '$hash' WHERE id = $uid");
        set_flash('success', 'Your password has been changed.');
        header('Location: settings.php');
        exit;
    }
}
?>
<h1>Settings</h1>
<?php foreach ($errors as $err): ?><div class="alert alert-error"><?php echo e($err); ?></div><?php endforeach; ?>
<form method="post" class="form-card">
    <h3>Change Password</h3>
    <?php echo csrf_field(); ?>
    <label>Current password</label>
    <input type="password" name="current" required>
    <label>New password (at least 8 characters)</label>
    <input type="password" name="new" required>
    <label>Confirm new password</label>
    <input type="password" name="confirm" required>
    <button type="submit" class="btn btn-burgundy">Change Password</button>
</form>
<?php require_once 'includes/footer.php'; ?>
