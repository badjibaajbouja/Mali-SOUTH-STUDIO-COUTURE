<?php
// admin/custom_orders.php - manage custom order requests
require_once 'includes/header.php';

$statuses = ['New', 'In Progress', 'Completed', 'Declined'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_check();
    $id = (int)$_POST['id'];
    if (isset($_POST['delete'])) {
        mysqli_query($conn, "DELETE FROM custom_orders WHERE id = $id");
        set_flash('success', 'Request deleted.');
    } elseif (in_array($_POST['status'], $statuses)) {
        $st = $_POST['status'];
        mysqli_query($conn, "UPDATE custom_orders SET status = '$st' WHERE id = $id");
        set_flash('success', 'Request updated.');
    }
    header('Location: custom_orders.php' . (isset($_POST['back']) && $_POST['back'] != '' ? '?' . $_POST['back'] : ''));
    exit;
}

$fs = isset($_GET['status']) ? $_GET['status'] : '';
$where = in_array($fs, $statuses) ? "WHERE status = '$fs'" : '';
$list = mysqli_query($conn, "SELECT * FROM custom_orders $where ORDER BY created_at DESC");
$back = $_SERVER['QUERY_STRING'];
?>
<h1>Custom Order Requests</h1>
<form method="get" class="toolbar">
    <select name="status">
        <option value="">All requests</option>
        <?php foreach ($statuses as $s): ?>
            <option <?php echo $fs == $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-burgundy btn-small">Filter</button>
    <a href="custom_orders.php" class="btn btn-outline btn-small">Reset</a>
</form>

<table class="table">
    <tr><th>Date</th><th>Customer</th><th>Request</th><th>Budget / Needed by</th><th>Status</th></tr>
    <?php if (mysqli_num_rows($list) == 0): ?>
        <tr><td colspan="5" class="empty-row">No requests found.</td></tr>
    <?php endif; ?>
    <?php while ($c = mysqli_fetch_assoc($list)): ?>
    <tr>
        <td><?php echo date('d M Y', strtotime($c['created_at'])); ?></td>
        <td><?php echo e($c['full_name']); ?><br><small><a href="mailto:<?php echo e($c['email']); ?>?subject=<?php echo rawurlencode('Your custom order request - Mali South Studio Couture'); ?>"><?php echo e($c['email']); ?></a><br><?php echo e($c['phone']); ?></small></td>
        <td><strong><?php echo e($c['request_type']); ?></strong><br><?php echo nl2br(e($c['description'])); ?></td>
        <td><?php echo e($c['budget']); ?><br><?php echo $c['needed_by'] ? date('d M Y', strtotime($c['needed_by'])) : '-'; ?></td>
        <td>
            <span class="status <?php echo status_class($c['status']); ?>"><?php echo e($c['status']); ?></span>
            <form method="post" class="inline-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo $c['id']; ?>">
                <input type="hidden" name="back" value="<?php echo e($back); ?>">
                <select name="status">
                    <?php foreach ($statuses as $s): ?>
                        <option <?php echo $c['status'] == $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-small btn-burgundy">Save</button>
            </form>
            <form method="post" onsubmit="return confirm('Delete this request?');">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo $c['id']; ?>">
                <input type="hidden" name="back" value="<?php echo e($back); ?>">
                <button type="submit" name="delete" value="1" class="link-btn">Delete</button>
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php require_once 'includes/footer.php'; ?>
