<?php
// logout.php - end the admin session
require_once 'includes/config.php';
$_SESSION = [];
session_destroy();
session_start();
set_flash('success', 'You have been logged out.');
header('Location: login.php');
exit;
