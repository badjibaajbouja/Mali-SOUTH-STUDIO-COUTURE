MALI SOUTH ADMIN PORTAL  (separate website from the customer shop)

1. Put this folder (MALISOUTHADMIN) in C:\xampp\htdocs
   NEXT TO the customer folder (MALISOUTHSTUDIOCOUTURE).
2. Start Apache and MySQL in XAMPP. The database (mali_south_db) is shared
   with the customer website, so import database.sql only once.
3. Open http://localhost/MALISOUTHADMIN/setup.php and create the admin account.
4. Delete setup.php.
5. Log in at http://localhost/MALISOUTHADMIN/login.php

If you rename a folder, change ADMIN_URL / CUSTOMER_URL in includes/config.php.
