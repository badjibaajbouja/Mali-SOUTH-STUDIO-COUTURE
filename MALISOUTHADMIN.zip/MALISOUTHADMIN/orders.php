<?php
// admin/orders.php - search orders and change their status
require_once 'includes/header.php';

$statuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_check();
    $id = (int)$_POST['order_id'];
    $new = $_POST['status'];
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT status FROM orders WHERE id = $id"));

    if ($row && in_array($new, $statuses) && $row['status'] != $new) {
        // checkout takes stock off, so a cancelled order must put it back (and the reverse)
        if ($new == 'Cancelled') {
            mysqli_query($conn, "UPDATE products p JOIN order_items i ON i.product_id = p.id SET p.stock = p.stock + i.quantity WHERE i.order_id = $id");
        } elseif ($row['status'] == 'Cancelled') {
            mysqli_query($conn, "UPDATE products p JOIN order_items i ON i.product_id = p.id SET p.stock = GREATEST(p.stock - i.quantity, 0) WHERE i.order_id = $id");
        }
        mysqli_query($conn, "UPDATE orders SET status = '$new' WHERE id = $id");
        set_flash('success', 'Order #' . $id . ' is now ' . $new . '.');
    }
    header('Location: orders.php' . (isset($_POST['back']) ? '?' . $_POST['back'] : ''));
    exit;
}

// ---- search / filter ----
$fs = isset($_GET['status']) ? $_GET['status'] : '';
$q  = isset($_GET['q']) ? trim($_GET['q']) : '';
$where = '1=1';
if (in_array($fs, $statuses)) { $where .= " AND o.status = '$fs'"; }
if ($q != '') {
    $qe = mysqli_real_escape_string($conn, $q);
    $qid = (int)$q;
    $where .= " AND (u.full_name LIKE '%$qe%' OR u.email LIKE '%$qe%' OR o.id = $qid)";
}
$orders = mysqli_query($conn, "SELECT o.*, u.full_name, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE $where ORDER BY o.created_at DESC");
$back = $_SERVER['QUERY_STRING'];
?>
<h1>Orders</h1>
<form method="get" class="toolbar">
    <input type="text" name="q" placeholder="Search by order number, customer name or email" value="<?php echo e($q); ?>">
    <select name="status">
        <option value="">All statuses</option>
        <?php foreach ($statuses as $s): ?>
            <option <?php echo $fs == $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-burgundy btn-small">Filter</button>
    <a href="orders.php" class="btn btn-outline btn-small">Reset</a>
</form>

<table class="table">
    <tr><th>Order</th><th>Customer</th><th>Delivery</th><th>Items</th><th>Total</th><th>Status</th></tr>
    <?php if (mysqli_num_rows($orders) == 0): ?>
        <tr><td colspan="6" class="empty-row">No orders found.</td></tr>
    <?php endif; ?>
    <?php while ($o = mysqli_fetch_assoc($orders)): ?>
    <?php $its = mysqli_query($conn, "SELECT * FROM order_items WHERE order_id = {$o['id']}"); ?>
    <tr>
        <td>#<?php echo $o['id']; ?><br><small><?php echo date('d M Y H:i', strtotime($o['created_at'])); ?></small></td>
        <td><?php echo e($o['full_name']); ?><br><small><?php echo e($o['email']); ?><br><?php echo e($o['phone']); ?></small></td>
        <td><small><?php echo e($o['address']); ?>, <?php echo e($o['city']); ?>, <?php echo e($o['postal_code']); ?><br>Payment: <?php echo e($o['payment_method']); ?></small></td>
        <td><small><?php while ($i = mysqli_fetch_assoc($its)) { echo e($i['product_name']) . ' x ' . $i['quantity'] . '<br>'; } ?></small></td>
        <td><?php echo money($o['total']); ?><br><small>incl. <?php echo money($o['shipping']); ?> delivery</small></td>
        <td>
            <span class="status <?php echo status_class($o['status']); ?>"><?php echo e($o['status']); ?></span>
            <form method="post" class="inline-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="order_id" value="<?php echo $o['id']; ?>">
                <input type="hidden" name="back" value="<?php echo e($back); ?>">
                <select name="status">
                    <?php foreach ($statuses as $s): ?>
                        <option <?php echo $o['status'] == $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-small btn-burgundy">Save</button>
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php require_once 'includes/footer.php'; ?>
